const APP_VISUALS = {
  mautic: { mark: "M", color: "#f45b3a", tone: "#fff1ec", label: "Featured" },
  postiz: { mark: "P", color: "#1868db", tone: "#eef5ff", label: "Social" },
  typebot: { mark: "T", color: "#0f766e", tone: "#e9fbf7", label: "Forms" },
  growthbook: { mark: "G", color: "#6f4bd8", tone: "#f3f0ff", label: "Experiments" },
  twenty: { mark: "20", color: "#1f2937", tone: "#f2f4f7", label: "CRM" },
};

const INSTALL_STEPS = [
  "App selected",
  "Preparing files",
  "Downloading app",
  "Starting services",
  "Checking app",
  "Ready",
];

const PHASE_INDEX = {
  queued: 1,
  validating: 1,
  pulling: 2,
  starting: 3,
  checking: 3,
  checking_app: 4,
  ready: 5,
  failed: 4,
  not_reachable: 4,
  canceling: 4,
  canceled: 4,
};

const initialAppIntent = appIntentFromLocation();

const state = {
  catalog: null,
  activeAppId: initialAppIntent || "mautic",
  intentAppId: initialAppIntent,
  job: null,
  pollTimer: null,
  compose: "",
  installCommand: "",
};

const appGrid = document.querySelector("#appGrid");
const appCount = document.querySelector("#appCount");
const catalogStatus = document.querySelector("#catalogStatus");
const selectedIcon = document.querySelector("#selectedIcon");
const selectedTitle = document.querySelector("#selectedTitle");
const selectedRole = document.querySelector("#selectedRole");
const selectedMeta = document.querySelector("#selectedMeta");
const installButton = document.querySelector("#installButton");
const cancelButton = document.querySelector("#cancelButton");
const openButton = document.querySelector("#openButton");
const statusTrack = document.querySelector("#statusTrack");
const projectName = document.querySelector("#projectName");
const bindHost = document.querySelector("#bindHost");
const includeOptional = document.querySelector("#includeOptional");
const resultPanel = document.querySelector("#resultPanel");
const resultTitle = document.querySelector("#resultTitle");
const resultSummary = document.querySelector("#resultSummary");
const endpointSummary = document.querySelector("#endpointSummary");
const resultOpenButton = document.querySelector("#resultOpenButton");
const resultDetails = document.querySelector("#resultDetails");
const composePreview = document.querySelector("#composePreview");
const installCommand = document.querySelector("#installCommand");
const copyInstallButton = document.querySelector("#copyInstallButton");
const copyComposeButton = document.querySelector("#copyComposeButton");

function activeApp() {
  return state.catalog?.apps.find((app) => app.id === state.activeAppId) || null;
}

function appIntentFromLocation() {
  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get("app");
  const fromHash = window.location.hash.match(/(?:^#|[?&])app=([^&]+)/)?.[1];
  const value = fromQuery || (fromHash ? decodeURIComponent(fromHash) : "");
  return /^[a-z0-9][a-z0-9_-]*$/i.test(value) ? value.toLowerCase() : "";
}

function endpointUrl(app) {
  const entry = app?.entrypoints?.[0];
  if (!entry) return "";
  return entry.url_template.replace("{port}", entry.default_host_port);
}

function endpointText(app) {
  const url = endpointUrl(app);
  return url || "No app link";
}

function visualFor(appId) {
  return APP_VISUALS[appId] || { mark: appId.slice(0, 1).toUpperCase(), color: "#425466", tone: "#f4f6f8", label: "App" };
}

function setIconStyle(element, visual) {
  element.textContent = visual.mark;
  element.style.setProperty("--icon-color", visual.color);
  element.style.setProperty("--icon-tone", visual.tone);
}

function setProjectFor(appId) {
  projectName.value = `shadyy-selector-${appId}`;
}

function syncLocationForApp(appId) {
  if (!window.history?.replaceState) return;
  const url = new URL(window.location.href);
  url.searchParams.set("app", appId);
  window.history.replaceState({}, "", url);
}

function setOpenTarget(url, enabled = Boolean(url)) {
  [openButton, resultOpenButton].forEach((button) => {
    button.href = enabled && url ? url : "#";
    button.classList.toggle("disabled", !(enabled && url));
    button.setAttribute("aria-disabled", String(!(enabled && url)));
  });
}

function renderStatus(stepIndex, status = "idle") {
  statusTrack.innerHTML = "";
  INSTALL_STEPS.forEach((step, index) => {
    const item = document.createElement("li");
    if (index < stepIndex) item.className = "done";
    if (index === stepIndex) {
      if (status === "error") item.className = "error";
      else if (status === "canceled" || status === "canceling") item.className = "canceled";
      else item.className = "active";
    }
    if (status === "ready" && index <= stepIndex) item.className = "done";
    item.textContent = step;
    statusTrack.append(item);
  });
}

function renderSelected() {
  const app = activeApp();
  if (!app) return;

  const visual = visualFor(app.id);
  setIconStyle(selectedIcon, visual);
  selectedTitle.textContent = app.display_name;
  selectedRole.textContent = app.role;
  selectedMeta.innerHTML = "";

  [
    ["Version", app.version],
    ["Services", app.service_count],
    ["Images", app.image_count],
    ["Local link", endpointText(app)],
  ].forEach(([label, value]) => {
    const row = document.createElement("div");
    const strong = document.createElement("strong");
    const span = document.createElement("span");
    strong.textContent = label;
    span.textContent = value;
    row.append(strong, span);
    selectedMeta.append(row);
  });

  const jobBelongsToApp = state.job?.app_id === app.id;
  installButton.disabled = false;
  installButton.textContent = jobBelongsToApp && state.job.status === "ready" ? "Reinstall" : "Install";
  cancelButton.hidden = true;
  cancelButton.disabled = true;
  setProjectFor(app.id);
  renderStatus(jobBelongsToApp ? PHASE_INDEX[state.job.phase] || 0 : 0, jobBelongsToApp ? state.job.status : "idle");
  setOpenTarget(jobBelongsToApp ? state.job.endpoint_url : "", jobBelongsToApp && state.job.open_enabled);
}

function clearPolling() {
  if (state.pollTimer) {
    clearTimeout(state.pollTimer);
    state.pollTimer = null;
  }
}

function selectApp(appId) {
  clearPolling();
  state.activeAppId = appId;
  state.intentAppId = appId;
  state.job = null;
  state.compose = "";
  state.installCommand = "";
  resultPanel.hidden = true;
  syncLocationForApp(appId);
  renderApps();
  renderSelected();
}

function renderApps() {
  appGrid.innerHTML = "";
  state.catalog.apps.forEach((app) => {
    const visual = visualFor(app.id);
    const card = document.createElement("button");
    card.className = `appCard ${state.activeAppId === app.id ? "selected" : ""}`;
    card.type = "button";
    card.addEventListener("click", () => selectApp(app.id));

    const top = document.createElement("div");
    top.className = "appTop";

    const icon = document.createElement("div");
    icon.className = "appIcon";
    setIconStyle(icon, visual);

    const titleWrap = document.createElement("div");
    const title = document.createElement("h3");
    const role = document.createElement("p");
    title.textContent = app.display_name;
    role.textContent = app.role;
    titleWrap.append(title, role);

    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = visual.label;
    top.append(icon, titleWrap, badge);

    const meta = document.createElement("div");
    meta.className = "cardMeta";
    const endpoint = document.createElement("span");
    endpoint.textContent = endpointText(app);
    const services = document.createElement("span");
    services.textContent = `${app.service_count} services`;
    meta.append(endpoint, services);

    const action = document.createElement("span");
    action.className = "cardAction";
    action.textContent = state.activeAppId === app.id ? "Selected" : "View";

    card.append(top, meta, action);
    appGrid.append(card);
  });
}

function preferredCommands(data) {
  const platform = navigator.platform.toLowerCase().includes("win") ? "powershell" : "posix";
  return data.command_sets?.[platform] || data.command_sets?.posix || data.commands || {};
}

function commandElement(command) {
  const code = document.createElement("code");
  code.textContent = command || "";
  return code;
}

function renderLog(job) {
  const code = document.createElement("code");
  code.textContent = job.logs?.length ? job.logs.slice(-80).join("\n") : "Waiting for install output.";
  return code;
}

function renderJob(job) {
  const app = activeApp();
  const commands = preferredCommands(job);
  const install = commands.install || "";
  const url = job.endpoint_url || endpointUrl(app);
  const stepIndex = PHASE_INDEX[job.phase] || 0;

  state.job = job;
  state.compose = job.compose_preview || "";
  state.installCommand = install;

  resultPanel.hidden = false;
  resultTitle.textContent = job.app_display_name || app.display_name;
  resultSummary.textContent = job.message || "Installing locally.";
  endpointSummary.textContent = job.open_enabled ? url : "Open will unlock when the app is reachable.";
  installCommand.innerHTML = "";
  installCommand.append(job.status === "running" || job.status === "ready" ? renderLog(job) : commandElement(install));
  composePreview.textContent = state.compose;
  resultDetails.innerHTML = "";

  [
    ["Project", job.project],
    ["Output", job.out_dir],
    ["Compose", job.files.compose],
    ["Env", job.files.env],
    ["Endpoint", url || "Not available"],
    ["Status", job.status],
  ].forEach(([label, value]) => {
    const row = document.createElement("div");
    const strong = document.createElement("strong");
    const span = document.createElement("span");
    strong.textContent = label;
    span.textContent = value;
    row.append(strong, span);
    resultDetails.append(row);
  });

  renderStatus(stepIndex, job.status);
  setOpenTarget(url, job.open_enabled);
  cancelButton.hidden = !job.cancel_enabled;
  cancelButton.disabled = !job.cancel_enabled || job.status === "canceling";
  cancelButton.textContent = job.status === "canceling" ? "Stopping" : "Stop Install";
  installButton.disabled = job.status === "queued" || job.status === "running" || job.status === "canceling";
  installButton.textContent = job.status === "ready" ? "Reinstall" : job.status === "error" || job.status === "canceled" ? "Try Again" : "Installing";
  renderApps();
}

async function pollJob(jobId) {
  try {
    const response = await fetch(`/api/install/${encodeURIComponent(jobId)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Install status failed: ${response.status}`);
    renderJob(data);
    if (data.status === "queued" || data.status === "running" || data.status === "canceling") {
      state.pollTimer = setTimeout(() => pollJob(jobId), 1500);
    } else {
      clearPolling();
    }
  } catch (error) {
    clearPolling();
    resultPanel.hidden = false;
    resultTitle.textContent = "Install status unavailable";
    resultSummary.textContent = error.message;
    installButton.disabled = false;
    installButton.textContent = "Try Again";
    cancelButton.hidden = true;
    cancelButton.disabled = true;
    renderStatus(4, "error");
  }
}

async function loadCatalog() {
  try {
    const response = await fetch("/api/catalog");
    if (!response.ok) throw new Error(`Catalog request failed: ${response.status}`);
    state.catalog = await response.json();
    if (state.intentAppId && state.catalog.apps.some((app) => app.id === state.intentAppId)) {
      state.activeAppId = state.intentAppId;
      syncLocationForApp(state.activeAppId);
    } else if (!activeApp()) {
      state.activeAppId = state.catalog.apps[0]?.id || "";
      if (state.activeAppId) syncLocationForApp(state.activeAppId);
    }
    catalogStatus.textContent = "Ready";
    catalogStatus.classList.add("success");
    appCount.textContent = `${state.catalog.apps.length} apps available`;
    renderApps();
    renderSelected();
  } catch (error) {
    catalogStatus.textContent = "Catalog error";
    catalogStatus.classList.add("error");
    appGrid.textContent = error.message;
    installButton.disabled = true;
  }
}

async function startInstall() {
  const app = activeApp();
  if (!app) return;

  clearPolling();
  installButton.disabled = true;
  installButton.textContent = "Starting";
  setOpenTarget("", false);
  renderStatus(1);

  try {
    const response = await fetch("/api/install", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        apps: [app.id],
        project: projectName.value,
        bind_host: bindHost.value,
        include_optional: includeOptional.checked,
      }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Install failed to start: ${response.status}`);
    renderJob(data);
    pollJob(data.job_id);
  } catch (error) {
    resultPanel.hidden = false;
    resultTitle.textContent = "Could not start install";
    resultSummary.textContent = error.message;
    installCommand.innerHTML = "";
    composePreview.textContent = "";
    renderStatus(1, "error");
    installButton.disabled = false;
    installButton.textContent = "Try Again";
    cancelButton.hidden = true;
    cancelButton.disabled = true;
  }
}

async function cancelInstall() {
  if (!state.job?.job_id || !state.job.cancel_enabled) return;

  cancelButton.disabled = true;
  cancelButton.textContent = "Stopping";
  resultSummary.textContent = "Stopping install.";

  try {
    const response = await fetch(`/api/install/${encodeURIComponent(state.job.job_id)}/cancel`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Stop failed: ${response.status}`);
    renderJob(data);
    pollJob(data.job_id);
  } catch (error) {
    resultSummary.textContent = error.message;
    cancelButton.disabled = false;
    cancelButton.textContent = "Stop Install";
  }
}

async function copyText(text, button, doneLabel) {
  if (!text) return;
  await navigator.clipboard.writeText(text);
  const original = button.textContent;
  button.textContent = doneLabel;
  setTimeout(() => {
    button.textContent = original;
  }, 1200);
}

installButton.addEventListener("click", startInstall);
cancelButton.addEventListener("click", cancelInstall);
copyInstallButton.addEventListener("click", () => copyText(state.installCommand, copyInstallButton, "Copied"));
copyComposeButton.addEventListener("click", () => copyText(state.compose, copyComposeButton, "Copied"));

renderStatus(0);
loadCatalog();
