#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
MINISTORE_DIR="$(cd "$SCRIPT_DIR/../.." && pwd -P)"
PORT="${SHADYY_SELECTOR_PORT:-4567}"
APP_ID="${SHADYY_SELECTOR_APP:-}"
OPEN_BROWSER=1
CHECK_ONLY=0

usage() {
  cat <<USAGE
Usage: shadyy-mini-store.command [--app APP] [--check] [--no-open] [--port PORT]

Options:
  --app APP    Open Mini-Store with this app selected, for example mautic or twenty.
  --check      Verify local dependencies and exit.
  --no-open    Start or reuse the selector without opening a browser.
  --port PORT  Selector port. Defaults to SHADYY_SELECTOR_PORT or 4567.
USAGE
}

log() {
  printf '%s\n' "==> $*"
}

fail() {
  printf '%s\n' "error: $*" >&2
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --app)
      [[ $# -ge 2 ]] || fail "--app requires a value"
      APP_ID="$2"
      shift 2
      ;;
    --check)
      CHECK_ONLY=1
      shift
      ;;
    --no-open)
      OPEN_BROWSER=0
      shift
      ;;
    --port)
      [[ $# -ge 2 ]] || fail "--port requires a value"
      PORT="$2"
      shift 2
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      fail "unknown option: $1"
      ;;
  esac
done

[[ "$PORT" =~ '^[0-9]+$' ]] || fail "port must be numeric"

if [[ -z "$APP_ID" && -f "$MINISTORE_DIR/default-app.txt" ]]; then
  APP_ID="$(head -n 1 "$MINISTORE_DIR/default-app.txt" | tr -d '[:space:]')"
fi
APP_ID="${APP_ID:-mautic}"
[[ "$APP_ID" =~ '^[A-Za-z0-9][A-Za-z0-9_-]*$' ]] || fail "app must use letters, numbers, dash, or underscore"
APP_ID="$(printf '%s' "$APP_ID" | tr '[:upper:]' '[:lower:]')"

require_command() {
  command -v "$1" >/dev/null 2>&1 || fail "$1 is required"
}

selector_url="http://127.0.0.1:${PORT}"
browser_url="${selector_url}/?app=${APP_ID}"
catalog_url="${selector_url}/api/catalog"

require_command ruby
require_command docker
require_command curl

docker compose version >/dev/null 2>&1 || fail "docker compose is required"
docker ps >/dev/null 2>&1 || fail "Docker is not reachable. Start Docker or Colima, then retry."

log "Ruby: $(ruby -v)"
log "Docker: $(docker --version)"
log "Compose: $(docker compose version)"
log "Selected app: ${APP_ID}"

if [[ "$CHECK_ONLY" -eq 1 ]]; then
  log "Dependency check passed."
  exit 0
fi

server_pid=""

cleanup() {
  if [[ -n "$server_pid" ]]; then
    log "Stopping selector server."
    kill "$server_pid" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT INT TERM

if curl -fsS "$catalog_url" >/dev/null 2>&1; then
  log "Selector already running at $selector_url"
else
  log "Starting selector at $selector_url"
  PORT="$PORT" ruby "$MINISTORE_DIR/bin/selector-server" &
  server_pid="$!"

  for _ in {1..40}; do
    if curl -fsS "$catalog_url" >/dev/null 2>&1; then
      break
    fi
    sleep 0.25
  done

  curl -fsS "$catalog_url" >/dev/null 2>&1 || fail "selector did not start at $selector_url"
fi

cat <<NEXT_STEPS

Shadyy Mini-Store is ready:
  $browser_url

Flow:
  1. Confirm ${APP_ID} is selected in the browser.
  2. Click Install.
  3. Wait for the local progress to finish.
  4. Click Open when the app is ready.

You can use Stop Install if the download/startup takes too long or you need to
cancel. Advanced run-bundle commands remain available in the browser for
recovery/debugging.

NEXT_STEPS

if [[ "$OPEN_BROWSER" -eq 1 ]]; then
  if command -v open >/dev/null 2>&1; then
    open "$browser_url" >/dev/null 2>&1 || true
  else
    log "Open command not found. Open the URL manually."
  fi
fi

if [[ -n "$server_pid" ]]; then
  log "Selector server is running. Press Control-C to stop it."
  wait "$server_pid"
else
  log "Selector was already running. Press Return to close this launcher."
  read -r
fi
