param(
  [switch]$Check,
  [switch]$NoOpen,
  [string]$App = $(if ($env:SHADYY_SELECTOR_APP) { $env:SHADYY_SELECTOR_APP } else { "" }),
  [string]$Port = $(if ($env:SHADYY_SELECTOR_PORT) { $env:SHADYY_SELECTOR_PORT } else { "4567" })
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

function Write-Log {
  param([string]$Message)
  Write-Host "==> $Message"
}

function Fail {
  param([string]$Message)
  Write-Host "error: $Message" -ForegroundColor Red
  exit 1
}

function Require-Command {
  param(
    [string]$Name,
    [string]$Help
  )
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    if ($Help) {
      Fail "$Name is required. $Help"
    }
    Fail "$Name is required"
  }
}

function Invoke-Checked {
  param(
    [string]$FilePath,
    [string[]]$Arguments,
    [string]$Help
  )

  try {
    & $FilePath @Arguments | Out-Null
    if ($LASTEXITCODE -ne 0) {
      if ($Help) {
        Fail "$FilePath $($Arguments -join ' ') failed. $Help"
      }
      Fail "$FilePath $($Arguments -join ' ') failed"
    }
  } catch {
    if ($Help) {
      Fail "$FilePath $($Arguments -join ' ') failed. $Help"
    }
    Fail "$FilePath $($Arguments -join ' ') failed"
  }
}

function Test-Catalog {
  param([string]$Url)

  try {
    Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2 | Out-Null
    return $true
  } catch {
    return $false
  }
}

[int]$ParsedPort = 0
if (-not [int]::TryParse($Port, [ref]$ParsedPort) -or $ParsedPort -lt 1 -or $ParsedPort -gt 65535) {
  Fail "port must be between 1 and 65535"
}
$Port = $ParsedPort

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MiniStoreDir = (Resolve-Path (Join-Path $ScriptDir "..\..")).Path
$SelectorServer = Join-Path $MiniStoreDir "bin\selector-server"
$DefaultAppPath = Join-Path $MiniStoreDir "default-app.txt"

if ([string]::IsNullOrWhiteSpace($App) -and (Test-Path $DefaultAppPath)) {
  $App = ((Get-Content $DefaultAppPath -TotalCount 1) -join "").Trim()
}
if ([string]::IsNullOrWhiteSpace($App)) {
  $App = "mautic"
}
if ($App -notmatch "^[A-Za-z0-9][A-Za-z0-9_-]*$") {
  Fail "app must use letters, numbers, dash, or underscore"
}
$App = $App.ToLowerInvariant()

$SelectorUrl = "http://127.0.0.1:$Port"
$BrowserUrl = "$SelectorUrl/?app=$App"
$CatalogUrl = "$SelectorUrl/api/catalog"

Require-Command ruby "Install Ruby for Windows, then reopen PowerShell and retry."
Require-Command docker "Install Docker Desktop, start it, then retry."

Invoke-Checked "docker" @("compose", "version") "Install or update Docker Desktop so Docker Compose is available."
Invoke-Checked "docker" @("ps") "Start Docker Desktop and wait until it says the engine is running."

Write-Log "Ruby: $(& ruby -v)"
Write-Log "Docker: $(& docker --version)"
Write-Log "Compose: $(& docker compose version)"
Write-Log "Selected app: $App"

if ($Check) {
  Write-Log "Dependency check passed."
  exit 0
}

$ServerProcess = $null
$PreviousPort = $env:PORT

try {
  if (Test-Catalog $CatalogUrl) {
    Write-Log "Selector already running at $SelectorUrl"
  } else {
    Write-Log "Starting selector at $SelectorUrl"
    $env:PORT = [string]$Port
    $ServerProcess = Start-Process -FilePath "ruby" -ArgumentList @("`"$SelectorServer`"") -WorkingDirectory $MiniStoreDir -PassThru -NoNewWindow
    $env:PORT = $PreviousPort

    for ($i = 0; $i -lt 40; $i++) {
      if (Test-Catalog $CatalogUrl) {
        break
      }
      Start-Sleep -Milliseconds 250
    }

    if (-not (Test-Catalog $CatalogUrl)) {
      Fail "selector did not start at $SelectorUrl"
    }
  }

  Write-Host ""
  Write-Host "Shadyy Mini-Store is ready:"
  Write-Host "  $BrowserUrl"
  Write-Host ""
  Write-Host "Flow:"
  Write-Host "  1. Confirm $App is selected in the browser."
  Write-Host "  2. Click Install."
  Write-Host "  3. Wait for the local progress to finish."
  Write-Host "  4. Click Open when the app is ready."
  Write-Host ""
  Write-Host "You can use Stop Install if the download/startup takes too long or you need to"
  Write-Host "cancel. Advanced run-bundle commands remain available in the browser for"
  Write-Host "recovery/debugging."
  Write-Host ""

  if (-not $NoOpen) {
    try {
      Start-Process $BrowserUrl | Out-Null
    } catch {
      Write-Log "Could not open the browser automatically. Open this URL manually: $BrowserUrl"
    }
  }

  if ($ServerProcess -ne $null) {
    Write-Log "Selector server is running. Press Control-C to stop it."
    Wait-Process -Id $ServerProcess.Id
  } else {
    Write-Log "Selector was already running. Press Enter to close this launcher."
    Read-Host | Out-Null
  }
} finally {
  $env:PORT = $PreviousPort
  if ($ServerProcess -ne $null -and -not $ServerProcess.HasExited) {
    Write-Log "Stopping selector server."
    Stop-Process -Id $ServerProcess.Id -Force -ErrorAction SilentlyContinue
  }
}
