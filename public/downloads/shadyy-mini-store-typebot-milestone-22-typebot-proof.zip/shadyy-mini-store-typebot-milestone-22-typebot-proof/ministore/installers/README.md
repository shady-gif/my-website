# Shadyy Mini-Store Installers

This folder contains local installer wrappers around the mini-store catalog,
selector, Compose generator, and run-bundle handoff.

The wrappers do not include the app source folders. They install from published
Docker images through generated Docker Compose bundles.

## Mac

Current wrapper:

```txt
mac/shadyy-mini-store.command
```

Run:

```sh
ministore/installers/mac/shadyy-mini-store.command
```

Open with an app preselected:

```sh
ministore/installers/mac/shadyy-mini-store.command --app mautic
ministore/installers/mac/shadyy-mini-store.command --app twenty
```

Check dependencies only:

```sh
ministore/installers/mac/shadyy-mini-store.command --check
```

The Mac wrapper:

```txt
1. Confirms Ruby, Docker, Docker Compose, and curl are available.
2. Confirms Docker is reachable.
3. Starts the local selector server, or reuses it if already running.
4. Opens http://127.0.0.1:4567/?app=mautic by default.
5. Lets the user confirm the selected app, Install, wait, and Open from the browser.
```

The wrapper opens the selector. The selector backend starts Docker installs
through `run-bundle`, tracks progress, supports Stop Install, and enables Open
only after the app answers locally. Advanced commands for `validate`, `install`,
`status`, `stop`, and `endpoints` remain available for recovery/debugging.

App intent can come from `--app`, `SHADYY_SELECTOR_APP`, or a packaged
`ministore/default-app.txt` file.

## Windows

Current wrapper:

```txt
windows/shadyy-mini-store.ps1
```

Run from PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1
```

Open with an app preselected:

```powershell
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1 -App mautic
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1 -App twenty
```

Check dependencies only:

```powershell
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1 -Check
```

The Windows wrapper mirrors the Mac wrapper:

```txt
1. Confirms Ruby, Docker, and Docker Compose are available.
2. Confirms Docker is reachable.
3. Starts the local selector server, or reuses it if already running.
4. Opens http://127.0.0.1:4567/?app=mautic by default.
5. Lets the user confirm the selected app, Install, wait, and Open from the browser.
```

Windows readiness notes:

```txt
Missing Ruby now points users to Ruby for Windows.
Missing Docker now points users to Docker Desktop.
Docker engine failures tell users to start Docker Desktop and wait for it.
Invalid ports are validated with a friendly message before launch.
Selector paths are quoted for folders with spaces.
Browser auto-open failure falls back to a manual URL message.
```

The wrapper is a script-first MVP, not a signed `.exe` or packaged installer.

On Windows, use the `.zip` package from `package-release --format both` and run
the PowerShell wrapper from the extracted `ministore` folder.

## Release Package

See the release handoff:

```txt
../RELEASE.md
```

Package the `ministore/` folder only. The package should include the catalog,
generator, selector, run-bundle script, public UI assets, and installer wrappers.
It should not include app source folders.

App-specific packages can be generated with:

```sh
ministore/bin/package-release --default-app mautic --format both
ministore/bin/package-release --default-app twenty --format both
```

Those archives include `ministore/default-app.txt`, so double-clicking the
launcher opens Mini-Store with that app already selected.

Current public rollout is Mautic-first. Twenty packages can still be generated
for testing, but Twenty should not be presented as a primary public download
until its full local install/open smoke passes.
