# Shadyy Mini-Store Release Handoff

This document describes the script-first release package for the local Shadyy
Mini-Store MVP.

The package installs from published Docker images. It must not include the app
source folders such as `postiz`, `mautic`, `typebot.io`,
`growthbook`, or `twenty-crm-manager`.

## Package Contents

Ship this folder as the package root:

```txt
ministore/
```

Required files:

```txt
catalog.yml
README.md
RELEASE.md
bin/generate-compose
bin/package-release
bin/package-share-page
bin/run-bundle
bin/selector-server
public/index.html
public/styles.css
public/app.js
share/index.html
share/styles.css
installers/README.md
installers/mac/shadyy-mini-store.command
installers/windows/shadyy-mini-store.ps1
```

Do not ship:

```txt
postiz/
mautic/
typebot.io/
typebot-fork/
growthbook/
twenty-crm-manager/
chatwoot/
.git/
```

## User Prerequisites

Mac:

```txt
Docker Desktop or a reachable Docker Engine
Docker Compose plugin
Ruby
curl
browser
network access to ghcr.io
```

Windows:

```txt
Docker Desktop
Docker Compose plugin
Ruby for Windows
PowerShell
browser
network access to ghcr.io
```

## Mac Run Commands

Dependency check:

```sh
ministore/installers/mac/shadyy-mini-store.command --check
```

Launch selector:

```sh
ministore/installers/mac/shadyy-mini-store.command
```

Optional test port:

```sh
ministore/installers/mac/shadyy-mini-store.command --no-open --port 4568
```

## Windows Run Commands

Dependency check:

```powershell
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1 -Check
```

Launch selector:

```powershell
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1
```

Optional test port:

```powershell
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1 -NoOpen -Port 4568
```

## First Smoke Checklist

Use `Mautic` as the first package smoke target because it is now the flagship
app for the local app-store journey.

1. Run the platform dependency check.
2. Launch the selector.
3. Open the selector URL.
4. Select `Mautic`.
5. Click `Install`.
6. Confirm progress advances through download/start/check phases.
7. Confirm `Stop Install` is available while the job is running.
8. Confirm `Open` stays disabled until the backend marks the app ready.
9. Confirm `http://localhost:8080` opens the Mautic web setup/login flow.
10. Run the generated `stop` command or `run-bundle --action down`.
11. Confirm the smoke containers stopped and volumes were preserved.

Expected boundary:

```txt
selector -> generates files and commands
selector backend -> runs run-bundle install from a local job
browser -> only talks to the local selector API
```

## Release Validation

Before sharing a package, run:

```sh
ruby -c ministore/bin/generate-compose
ruby -c ministore/bin/package-release
ruby -c ministore/bin/selector-server
ruby -c ministore/bin/run-bundle
zsh -n ministore/installers/mac/shadyy-mini-store.command
ministore/installers/mac/shadyy-mini-store.command --check
ruby ministore/bin/package-release --out /private/tmp/shadyy-mini-store-releases --format both
```

If PowerShell is available, also run:

```powershell
powershell -ExecutionPolicy Bypass -File ministore\installers\windows\shadyy-mini-store.ps1 -Check
```

## Known MVP Limits

```txt
Mac wrapper is a .command script, not a signed .app.
Windows wrapper is a PowerShell script, not a signed .exe.
Static shared-link page package exists, but it is not deployed to a public URL yet.
The selector runs locally from the package.
Docker app installation runs through the local selector backend; run-bundle
commands remain available for recovery/debugging.
Windows wrapper still needs a real Windows or pwsh execution smoke.
```

## Next Recommended Work

```txt
1. Continue the same proof path for the next internal app before enabling more public download buttons.
2. Deploy the website Mini Store page to a public URL when the user approves pushing.
3. Run the Windows wrapper on an actual Windows laptop.
4. Add signed/native packaging only after the script package is stable.
```

## Latest Local Smoke Target

Current first smoke target:

```txt
app: Mautic
expected URL: http://localhost:8080
```

## Latest Twenty Proof Smoke

Twenty has passed the Mac selector install/open path. The user approved adding
Twenty download buttons to the website Mini Store page.

```txt
date: 2026-07-08
selector port: 4597
job id: 20260708172224-388d9693
project: shadyy-proof-twenty-fixed
endpoint: http://localhost:2020
result: selector status ready, open_enabled true, HTTP 200 from localhost
catalog fix: added APP_VERSION=0.1.1 to twenty-server and twenty-worker
```

## Milestone 19 Twenty Website Button

Twenty was promoted from pending to public on the website Mini Store page.

```txt
website page: my-website/app/mini-store/page.tsx
download directory: my-website/public/downloads
mac package: shadyy-mini-store-twenty-milestone-19-twenty-public.tar.gz
windows package: shadyy-mini-store-twenty-milestone-19-twenty-public.zip
status: page offers Mautic and Twenty download buttons
boundary: Windows real smoke is still pending; website push is not done yet
```

## Milestone 20 Postiz Proof Smoke

Postiz passed the Mac selector install/open path and is now the next pending
candidate for public website buttons.

```txt
date: 2026-07-08
selector port: 4598
job id: 20260708175337-5d3796c3
project: shadyy-proof-postiz
endpoint: http://localhost:4007
result: selector status ready, open_enabled true, HTTP 307 to /auth from localhost
package mac: shadyy-mini-store-postiz-milestone-20-postiz-proof.tar.gz
package windows: shadyy-mini-store-postiz-milestone-20-postiz-proof.zip
boundary: Postiz buttons are not on the website until user approval
```

## Milestone 21 Postiz Website Button

Postiz was promoted from pending to public on the website Mini Store page.

```txt
website page: my-website/app/mini-store/page.tsx
download directory: my-website/public/downloads
mac package: shadyy-mini-store-postiz-milestone-20-postiz-proof.tar.gz
windows package: shadyy-mini-store-postiz-milestone-20-postiz-proof.zip
status: page offers Mautic, Twenty, and Postiz download buttons
boundary: Windows real smoke is still pending; website push is not done yet
```

## Milestone 22 Typebot Proof Attempt

Typebot package intent was generated and the selector install was attempted, but
the local Docker runtime ran out of disk space while extracting a Typebot image
layer.

```txt
date: 2026-07-08
selector port: 4599
job id: 20260708182037-52654f53
project: shadyy-proof-typebot
builder endpoint: http://localhost:8082
viewer endpoint: http://localhost:8081
package mac: shadyy-mini-store-typebot-milestone-22-typebot-proof.tar.gz
package windows: shadyy-mini-store-typebot-milestone-22-typebot-proof.zip
result: blocked by local Docker disk space during docker compose pull
error: no space left on device while extracting Typebot layer
cleanup performed: no Typebot containers were running; selector stopped
next action: user-approved Docker cleanup, then rerun the same Typebot smoke
```

## Latest Package Archive

The package script produced and validated these archives:

```txt
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-milestone-15g-shared-link-page.tar.gz
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-milestone-15g-shared-link-page.zip
root: shadyy-mini-store-milestone-15g-shared-link-page/ministore
sizes: 34K tar.gz, 43K zip
```

Validation included the package script's explicit allowlist and forbidden
source-folder checks.

## Windows Readiness

The Windows-ready package pass added:

```txt
cross-platform generated bundle root: <OS temp dir>/shadyy-selector-runs
override: SHADYY_SELECTOR_RUNS_DIR
selector API command_sets.posix
selector API command_sets.powershell
package-release --format tar.gz|zip|both
Windows-friendly .zip archive
```

Latest Windows-ready archives:

```txt
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-milestone-14a-windows-ready.tar.gz
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-milestone-14a-windows-ready.zip
```

Milestone 15F updated the Windows PowerShell wrapper for the browser-driven
Mautic install flow:

```txt
Click Mautic
Click Install
Wait through progress
Use Stop Install if needed
Click Open after readiness
```

Windows wrapper readiness improvements:

```txt
Friendly Ruby for Windows guidance when ruby is missing.
Friendly Docker Desktop guidance when docker is missing or unreachable.
Friendly Docker Compose guidance when compose is unavailable.
Friendly numeric port validation before launch.
Quoted selector-server path for extracted package paths containing spaces.
Browser auto-open fallback prints the manual selector URL.
```

## App Store UI

Milestone 15B replaced the technical bundle-selector surface with an
app-store-style local catalog:

```txt
Mautic is selected by default.
Apps appear as icon cards.
The selected app panel has Install and Open actions.
Generated Docker details are kept behind advanced/generated-file sections.
The normal Mautic target remains http://localhost:8080.
```

Previous Milestone 15B boundary:

```txt
Install prepares the local bundle and generated run-bundle command.
The browser still does not execute Docker directly.
One-click Docker execution should be a separate approved milestone.
```

## Local Runtime Install API

Milestone 15C added browser-started local installs:

```txt
POST /api/install -> generates a bundle and starts a local install job
GET /api/install/<job-id> -> returns status, phase, logs, endpoint, and Open readiness
selector-server -> runs run-bundle install in the background
UI -> polls the job and unlocks Open only after the localhost app answers
```

Friendly phases:

```txt
Checking local app files
Downloading app files
Starting local services
Checking running services
Waiting for the app to open locally
Ready to open
```

Runtime logs are capped and sensitive values are redacted before they are
returned to the browser.

## Stop Install And Full Mautic Smoke

Milestone 15D added a cancel route and Stop Install button:

```txt
POST /api/install/<job-id>/cancel -> requests cancellation
selector-server -> terminates the install process group
selector-server -> runs bundle down cleanup when needed
UI -> shows Stop Install while cancel_enabled is true
UI -> shows Try Again after canceled/error jobs
```

Cancel smoke:

```txt
job: 20260706182206-484a2e34
app: Mautic
project: shadyy-cancel-smoke-mautic
result: canceled
cleanup: no Mautic containers or install processes remained
```

Full local runtime smoke:

```txt
POST /api/install app=mautic
job: 20260706182705-9f60f933
project: shadyy-full-smoke-mautic
endpoint: http://localhost:8080
result: ready
open_enabled: true
localhost response: HTTP 302
cleanup: run-bundle down stopped the smoke containers and preserved volumes
```

## Mac Wrapper End-To-End Smoke

Milestone 15E proved the Mac wrapper as the non-technical entrypoint:

```txt
Open Mac wrapper
Selector starts locally
Browser opens selector URL
Mautic is selected
Click Install
Wait until Ready to open
Click Open
Mautic opens at localhost
```

Validation:

```txt
zsh -n ministore/installers/mac/shadyy-mini-store.command
ministore/installers/mac/shadyy-mini-store.command --check
wrapper-launched selector: http://127.0.0.1:4592
browser page title: Shadyy Store
Install UI state: Installing -> Ready to open
Open target: http://localhost:8080/installer
Mautic page title: Install | Shadyy Signal
localhost response: HTTP 302
cleanup: run-bundle down stopped shadyy-selector-mautic containers
selector cleanup: wrapper server stopped, port 4592 closed
normal wrapper mode: http://127.0.0.1:4593/api/catalog returned HTTP 200
```

## Windows Wrapper Readiness Pass

Milestone 15F prepared the Windows wrapper for the current app-store flow. This
was a code/documentation readiness pass only; PowerShell was not available on
the Mac test machine, so a real Windows execution smoke remains pending.

Changed active surfaces:

```txt
ministore/installers/windows/shadyy-mini-store.ps1
ministore/installers/README.md
ministore/RELEASE.md
WORKSPACE_STATUS.md
HANDOFF.md
```

Validation available on this machine:

```txt
static wrapper inspection
package-release allowlist and forbidden source-folder checks
Mac wrapper syntax check
selector-server syntax check
public app JavaScript syntax check
active catalog/public/registry n8n check
```

## Shared Link Download Page

Milestone 15G added the first static "open a link" surface for companies:

```txt
ministore/share/index.html
ministore/share/styles.css
ministore/bin/package-share-page
```

The page gives companies the Mac and Windows downloads first, then shows the
plain-language Mautic journey:

```txt
Open package
Click Mautic
Click Install
Click Open
Use Mautic locally
```

Package command:

```sh
ruby ministore/bin/package-share-page --release-dir /private/tmp/shadyy-mini-store-releases --out /private/tmp/shadyy-mini-store-share --version milestone-15g-shared-link-page
```

Latest share page package:

```txt
/private/tmp/shadyy-mini-store-share/shadyy-mini-store-milestone-15g-shared-link-page-share-page.zip
root: shadyy-mini-store-milestone-15g-shared-link-page-share
contents: index.html, styles.css, downloads/, SHA256SUMS.txt, SHARE_MANIFEST.txt
size: 84K
```

Boundary:

```txt
This is a host-ready static package.
It has not been deployed to a public URL yet.
```

## Milestone 16 App-Specific Install Intent

The Mini Store now supports app-specific packages while keeping one installer
engine underneath.

Changed active surfaces:

```txt
ministore/public/app.js -> honors ?app=mautic and ?app=twenty
ministore/installers/mac/shadyy-mini-store.command -> supports --app and default-app.txt
ministore/installers/windows/shadyy-mini-store.ps1 -> supports -App and default-app.txt
ministore/bin/package-release -> supports --default-app APP
ministore/bin/package-share-page -> packages app-specific downloads
ministore/share/index.html -> shows Mautic/Twenty Mac and Windows downloads
ministore/installers/README.md -> documents app intent
```

Generated app-specific archives:

```txt
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-mautic-milestone-16-app-intent.tar.gz
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-mautic-milestone-16-app-intent.zip
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-twenty-milestone-16-app-intent.tar.gz
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-twenty-milestone-16-app-intent.zip
/private/tmp/shadyy-mini-store-share/shadyy-mini-store-milestone-16-app-intent-share-page.zip
```

Validation:

```txt
ruby -c ministore/bin/package-release
ruby -c ministore/bin/package-share-page
ruby -c ministore/bin/selector-server
node --check ministore/public/app.js
zsh -n ministore/installers/mac/shadyy-mini-store.command
package markers verified: Mautic archive has default-app.txt=mautic, Twenty archive has default-app.txt=twenty
share zip contains all four app-specific downloads
active catalog/public/share/registry surfaces have no n8n references
```

## Milestone 17 Twenty Mac Smoke Attempt

A full Twenty install/open smoke was attempted through the selector API using
the same path the browser UI calls.

Smoke setup:

```txt
selector: http://127.0.0.1:4595
project: shadyy-full-smoke-twenty
run dir: /private/tmp/shadyy-twenty-smoke-runs/20260707164505-c152abc2
endpoint: http://localhost:2020
existing Twenty stack on port 3000 was left untouched
```

Result:

```txt
status: canceled after the planned smoke window
last phase: pulling
open_enabled: false
containers started: none
port 2020 after cleanup: free
docker ps after cleanup: only the pre-existing Twenty containers remained
```

Interpretation:

```txt
The installer generated the correct Twenty bundle and started the real install
path, but the first GHCR image pull was too slow to reach container startup
within the smoke window. This is not yet a functional Twenty pass or fail.
Twenty should not be treated as equally proven with Mautic until a full pull,
startup, readiness, open, and cleanup smoke succeeds.
```

## Milestone 18 Mautic-First Public Artifact

Option A was selected for rollout: publish Mautic first and keep Twenty visible
as pending final smoke rather than offering it as an equal public download.

Changed active surfaces:

```txt
ministore/share/index.html -> Mautic-only download buttons, Twenty pending notice
ministore/share/styles.css -> pending notice/card styles
ministore/bin/package-share-page -> default apps changed to mautic only
ministore/installers/README.md -> documents Mautic-first rollout boundary
```

Generated artifacts:

```txt
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-mautic-milestone-18-mautic-first-public.tar.gz
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-mautic-milestone-18-mautic-first-public.zip
/private/tmp/shadyy-mini-store-share/shadyy-mini-store-milestone-18-mautic-first-public-share-page.zip
```

Validation:

```txt
ruby -c ministore/bin/package-share-page
ruby -c ministore/bin/package-release
node --check ministore/public/app.js
zsh -n ministore/installers/mac/shadyy-mini-store.command
Mautic archive default-app.txt verified as mautic
share package contains only Mautic Mac and Windows downloads
share HTML shows Twenty as pending final smoke with no Twenty download links
active catalog/public/share/registry surfaces have no n8n references
```

Boundary:

```txt
This is still a host-ready package, not deployed to shadyy.org yet.
Website integration/deployment remains a separate approved milestone.
```

## Milestone 19 Future App Onboarding Pipeline

Milestone 19 added an internal promotion system for adding future Mini Store
apps one by one without overexposing unproven apps.

Added files:

```txt
ministore/APP_ONBOARDING.md
ministore/app-readiness.yml
```

Promotion states:

```txt
internal -> pending -> public
```

Current app positions:

```txt
Mautic: public-first
Twenty: pending final smoke
Postiz: internal
Typebot: internal
GrowthBook: internal
n8n: removed from active user-facing scope
```

Rule:

```txt
Do not enable public download buttons only because an image exists.
Enable downloads only after the app-specific package and install/open flow are
proven enough for a non-technical company.
```

## Milestone 22 Typebot Runtime Proof

Typebot was moved through the app-specific package and local runtime proof path.

Generated artifacts:

```txt
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-typebot-milestone-22-typebot-proof.tar.gz
/private/tmp/shadyy-mini-store-releases/shadyy-mini-store-typebot-milestone-22-typebot-proof.zip
```

Smoke notes:

```txt
selector: http://127.0.0.1:4599
job: 20260709165435-bf20fe48
project: shadyy-proof-typebot-rerun
builder: http://localhost:8082 -> HTTP 307 /signin
viewer: http://localhost:8081 -> HTTP 404 without server crash
```

Fixes applied:

```txt
Docker image cleanup cleared the previous local disk blocker.
The missing Typebot viewer image was pulled separately after GHCR timed out.
TYPEBOT_ENCRYPTION_SECRET generation now uses a 32-character value because
Typebot rejects longer encryption secrets at runtime.
```

Boundary:

```txt
Typebot is ready for the next approval step, but it has not been added to the
public shadyy.org Mini Store page and public download buttons remain disabled.
```
