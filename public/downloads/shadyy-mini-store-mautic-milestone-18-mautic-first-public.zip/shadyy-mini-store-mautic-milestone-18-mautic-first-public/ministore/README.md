# Shadyy Mini-Store Catalog

This folder is the local mini-store MVP: catalog, Compose generator, selector
server/UI, run-bundle handoff, and script-first Mac/Windows launchers.

`catalog.yml` is the installer-facing source of truth for:

- app ids and display names
- published GHCR image tags
- default host ports
- required support services
- persistent volumes
- generated secrets
- optional integration environment variables

Installers should use this catalog through the Compose generator, preserve
generated secrets between updates, and perform Mode 1 updates:

```txt
fetch catalog
render compose for selected apps
docker compose pull
docker compose up -d
```

## Compose Generator

Milestone 5 added a local generator:

```txt
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/bin/generate-compose
```

Usage:

```sh
ruby ministore/bin/generate-compose --apps mautic --out /private/tmp/shadyy-compose-mautic
ruby ministore/bin/generate-compose --apps mautic,postiz --out /private/tmp/shadyy-compose-mautic-postiz
ruby ministore/bin/generate-compose --apps all --out /private/tmp/shadyy-compose-all
ruby ministore/bin/generate-compose --apps typebot --include-optional --out /private/tmp/shadyy-compose-typebot-optional
```

The generator writes:

```txt
docker-compose.yml
.env
endpoints.txt
```

Generated secrets are written to `.env` and preserved on rerun. Ports bind to
`127.0.0.1` by default, and the bind host can be changed with `--bind-host`.

Validation command:

```sh
docker compose --env-file /path/to/output/.env -f /path/to/output/docker-compose.yml config
```

## Selector Server

Milestone 7 added a local selector/backend surface:

```txt
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/bin/selector-server
```

Run it from the workspace root:

```sh
ruby ministore/bin/selector-server
```

Default URL:

```txt
http://127.0.0.1:4567
```

The server provides:

```txt
GET  /api/catalog
POST /api/generate
POST /api/install
GET  /api/install/<job-id>
POST /api/install/<job-id>/cancel
```

`POST /api/generate` accepts JSON:

```json
{
  "apps": ["mautic"],
  "project": "shadyy-selector-mautic",
  "bind_host": "127.0.0.1",
  "include_optional": false
}
```

Generated bundles are written under:

```txt
<OS temp dir>/shadyy-selector-runs
```

Set `SHADYY_SELECTOR_RUNS_DIR` to override the generated bundle root.

The browser selector generates Compose files and endpoints. For installs, it
starts a local selector job that runs `run-bundle install` under the hood,
tracks progress, lets the user stop a running install, and unlocks Open only
after the localhost app answers.

Milestone 15B rebuilt the selector into an app-store-style UI. Milestone 15C
added the local runtime install API. Milestone 15D added Stop Install and
proved the full Mautic ready path. Milestone 15E proved the Mac wrapper
entrypoint into the same Mautic flow. The default first app is Mautic, and the
main flow is:

```txt
Select app card
Install
Wait through local progress
Stop Install if the user needs to cancel a long pull/startup
Open the localhost app link
```

The generated command is still shown in Advanced details for recovery/debugging,
but it is no longer the primary non-technical path.

Generated responses include handoff commands for:

```txt
validate
install
install_skip_pull
status
stop
endpoints
```

Responses also include `command_sets.posix` and `command_sets.powershell` so
the browser can show commands that paste cleanly into macOS/Linux shells and
Windows PowerShell.

Validation performed during Milestone 7:

```sh
ruby -c ministore/bin/selector-server
curl http://127.0.0.1:4567/api/catalog
curl -X POST http://127.0.0.1:4567/api/generate ...
docker compose --env-file /private/tmp/shadyy-selector-runs/<run-id>/.env -f /private/tmp/shadyy-selector-runs/<run-id>/docker-compose.yml config
```

## Run Bundle Handoff

Milestone 8 added a script-first Docker runtime handoff:

```txt
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/bin/run-bundle
```

Usage:

```sh
ruby ministore/bin/run-bundle --bundle /path/to/generated/<run-id> --action validate
ruby ministore/bin/run-bundle --bundle /path/to/generated/<run-id> --action install
ruby ministore/bin/run-bundle --bundle /path/to/generated/<run-id> --action status
ruby ministore/bin/run-bundle --bundle /path/to/generated/<run-id> --action down
```

Actions:

```txt
validate  -> docker compose config
pull      -> docker compose pull
up        -> docker compose up -d
down      -> docker compose down
status    -> docker compose ps
endpoints -> print endpoints.txt
install   -> validate, pull, up, status, endpoints
restart   -> down, up, endpoints
```

Volumes are preserved by default. `--remove-volumes` is available only with
`down` or `restart`, and should be used only when data deletion is intended.

Validation performed during Milestone 8:

```sh
ruby -c ministore/bin/run-bundle
ruby ministore/bin/run-bundle --bundle /private/tmp/shadyy-selector-runs/20260704183451-b3f21f71 --action install
curl http://localhost:8080
ruby ministore/bin/run-bundle --bundle /private/tmp/shadyy-selector-runs/20260704183451-b3f21f71 --action down
```

## Installer Wrappers

Milestone 9 added the Mac script-wrapper MVP:

```txt
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/installers/mac/shadyy-mini-store.command
```

Run:

```sh
ministore/installers/mac/shadyy-mini-store.command
```

Check dependencies only:

```sh
ministore/installers/mac/shadyy-mini-store.command --check
```

The wrapper checks Ruby, Docker, Docker Compose, curl, and Docker reachability,
then starts or reuses the selector and opens the browser. The selector can now
start Docker installs through the local backend; generated `run-bundle`
commands remain available in Advanced details for recovery/debugging.

Validation performed during Milestone 9:

```sh
zsh -n ministore/installers/mac/shadyy-mini-store.command
ruby -c ministore/bin/selector-server
ruby -c ministore/bin/run-bundle
ministore/installers/mac/shadyy-mini-store.command --check
ministore/installers/mac/shadyy-mini-store.command --no-open --port 4568
curl http://127.0.0.1:4568/api/catalog
```

Validation performed during Milestone 15E:

```sh
zsh -n ministore/installers/mac/shadyy-mini-store.command
ministore/installers/mac/shadyy-mini-store.command --check
SHADYY_SELECTOR_RUNS_DIR=/private/tmp/shadyy-mac-wrapper-smoke-runs ministore/installers/mac/shadyy-mini-store.command --no-open --port 4592
SHADYY_SELECTOR_RUNS_DIR=/private/tmp/shadyy-mac-wrapper-open-smoke-runs ministore/installers/mac/shadyy-mini-store.command --port 4593
```

The wrapper-launched selector was then opened in the browser, Mautic was
installed from the UI, Open reached `http://localhost:8080/installer`, and the
smoke stack was stopped with `run-bundle down`. The normal browser-open wrapper
mode also started on port 4593 and returned HTTP 200 from `/api/catalog`.

Open decisions for future milestones:

- Mac and Windows installer output paths
- whether optional services like Typebot Mailpit or Postiz Temporal UI should be exposed by default
- whether to package the Mac wrapper as a signed `.app`
- whether to package the Windows wrapper as a signed `.exe` or keep it script-first
- release/package handoff docs for Mac and Windows users

## Release Handoff

Milestone 11 added package handoff docs:

```txt
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/RELEASE.md
```

The release package is the `ministore/` folder only. It should not include app
source folders such as `postiz`, `mautic`, `typebot.io`,
`growthbook`, or `twenty-crm-manager`.

## Shared Link Page

Milestone 15G added a static first-link/download surface:

```txt
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/share/index.html
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/share/styles.css
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/bin/package-share-page
```

Build the local runtime archives first, then package the host-ready share page:

```sh
ruby ministore/bin/package-release --out /private/tmp/shadyy-mini-store-releases --version milestone-15g-shared-link-page --format both
ruby ministore/bin/package-share-page --release-dir /private/tmp/shadyy-mini-store-releases --out /private/tmp/shadyy-mini-store-share --version milestone-15g-shared-link-page
```

The share page package contains:

```txt
index.html
styles.css
downloads/<Mac tar.gz>
downloads/<Windows zip>
SHA256SUMS.txt
SHARE_MANIFEST.txt
```

This is host-ready static output, not a deployed public domain yet.

## Package Archive

Milestone 13 added a package archive script:

```txt
/Users/sarrthakchauhan/Documents/The Marketing Startup/ministore/bin/package-release
```

Usage:

```sh
ruby ministore/bin/package-release --out /private/tmp/shadyy-mini-store-releases --format both
```

The script copies an explicit allowlist from `ministore/`, writes
`RELEASE_MANIFEST.txt`, creates `.tar.gz` and/or `.zip` archives, and validates
that app source folders and `.git` metadata are not present. Use the `.zip`
archive for Windows smoke tests.
